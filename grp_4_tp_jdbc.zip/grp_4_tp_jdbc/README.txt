1# Ajouter la librairie pour la gestion du driver de base de donnée
2# Renseigner les données de connexion dans le fichier db.properties
3# Run