package Entity;

public enum ItemStatus {
    sold,
    for_sell
}
